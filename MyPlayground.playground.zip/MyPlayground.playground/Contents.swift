//: A UIKit based Playground for presenting user interface
  
import UIKit
import PlaygroundSupport

class MyViewController : UIViewController {
    override func loadView() {
        let view = UIView(frame:  CGRect(x: 0, y: 0, width: 600, height: 600))
        view.backgroundColor = .black

        let label = UITextView()
        label.frame = CGRect(x: 190, y: 200, width: 300, height: 40)
        label.typeOn(string: "at the beginning, there was nothing...\n\t   and then, there was:")
        label.textColor = .white
        label.backgroundColor = .black
        label.isEditable = false
        
        let bgmWhite = UIImage(named: "zathI.png")
        let bgmView = UIImageView(image: bgmWhite)
        bgmView.frame = CGRect(x: 80, y: 300, width: 450, height: 80)
        
//        let bgmG = UIImage(named: "bgmG.png")
//        let bgmViewG = UIImageView(image: bgmWhite)
//        bgmViewG.frame = CGRect(x: 70, y: 290, width: 450, height: 80)
//
//        let bgmP = UIImage(named: "bgmP.png")
//        let bgmViewP = UIImageView(image: bgmWhite)
//        bgmViewP.frame = CGRect(x: 90, y: 310, width: 450, height: 80)
        
       
        
        view.addSubview(label)
//        sleep(5)
        DispatchQueue.main.asyncAfter(deadline: .now() + 6.5) {
            view.addSubview(bgmView)
            UIView.animate(withDuration: 2, animations: {
                let transform1 = CGAffineTransform(translationX: 0, y: -300)
                let transform2 = CGAffineTransform(translationX: 0, y: -250)
                label.transform = transform1
                bgmView.transform = transform2
            }, completion: { finished in
                let describe = UITextView()
                describe.frame = CGRect(x: 150, y: 150, width: 300, height: 40)
                describe.typeOn(string: "many terms and tropes have been used to vilify us:")
                describe.textColor = .white
                describe.backgroundColor = .black
                describe.isEditable = false
                view.addSubview(describe)
                let insults = UILabel()
                insults.frame = CGRect(x: 0, y: 160, width: 3000, height: 100)
                insults.text = "MAMMY. JEZEBEL. SAPPHIRE. TRAGIC MULATTA. WELFARE QUEEN. ANGRY BLACK WOMAN."
                insults.textColor = .red
                insults.font = insults.font.withSize(70)
                insults.font = UIFont.boldSystemFont(ofSize: 70.0)
                view.addSubview(insults)
                UIView.animate(withDuration: 20, animations: {
                    let slide = CGAffineTransform(translationX: -3000, y: 0)
                    insults.transform = slide
                }, completion: { finished in
                    let but = UITextView()
                    but.frame = CGRect(x: 150, y: 140, width: 350, height: 40)
                    but.typeOn(string: "yet still, we rise above. see our artistry. hear our stories.")
                    but.textColor = .white
                    but.backgroundColor = .black
                    but.isEditable = false
                    view.addSubview(but)
                    
                    let ida = UIImage(named: "idabwells.png")
                    let idaView = UIImageView(image: ida)
                    idaView.frame = CGRect(x: 0, y: 190, width: 50, height: 50)
                    view.addSubview(idaView)
                    let txt1 = UITextView()
                    txt1.frame = CGRect(x: 60, y: 190, width: 200, height: 40)
                    txt1.typeOn(string: "IDA B WELLS.\nTHE JOURNALIST.")
                    txt1.textColor = .white
                    txt1.backgroundColor = .black
                    txt1.isEditable = false
                    view.addSubview(txt1)
                    
                    let wan = UIImage(named: "wangarimaathai.png")
                    let wanView = UIImageView(image: wan)
                    wanView.frame = CGRect(x: 300, y: 190, width: 50, height: 50)
                    view.addSubview(wanView)
                    let txt2 = UITextView()
                    txt2.frame = CGRect(x: 360, y: 190, width: 200, height: 40)
                    txt2.typeOn(string: "WANGARI MAATHAI.\nTHE ENVIRONMENTALIST.")
                    txt2.textColor = .white
                    txt2.backgroundColor = .black
                    txt2.isEditable = false
                    view.addSubview(txt2)
                    
                    let mur = UIImage(named: "murielpetioni.png")
                    let murView = UIImageView(image: mur)
                    murView.frame = CGRect(x: 0, y: 250, width: 50, height: 50)
                    view.addSubview(murView)
                    let txt3 = UITextView()
                    txt3.frame = CGRect(x: 60, y: 250, width: 200, height: 40)
                    txt3.typeOn(string: "MURIEL PETIONI.\nTHE CARETAKER.")
                    txt3.textColor = .white
                    txt3.backgroundColor = .black
                    txt3.isEditable = false
                    view.addSubview(txt3)
                    
                    let mah = UIImage(named: "mahaliajackson.png")
                    let mahView = UIImageView(image: mah)
                    mahView.frame = CGRect(x: 300, y: 250, width: 50, height: 50)
                    view.addSubview(mahView)
                    let txt4 = UITextView()
                    txt4.frame = CGRect(x: 360, y: 250, width: 200, height: 40)
                    txt4.typeOn(string: "MAHALIA JACKSON.\nTHE CREATIVE VISIONARY.")
                    txt4.textColor = .white
                    txt4.backgroundColor = .black
                    txt4.isEditable = false
                    view.addSubview(txt4)
                    
                    let mam = UIImage(named: "mamiephillipsclark.png")
                    let mamView = UIImageView(image: mam)
                    mamView.frame = CGRect(x: 0, y: 310, width: 50, height: 50)
                    view.addSubview(mamView)
                    let txt5 = UITextView()
                    txt5.frame = CGRect(x: 60, y: 310, width: 200, height: 40)
                    txt5.typeOn(string: "DR. MAMIE PHILLIPS CLARK.\nTHE RESEARCHER.")
                    txt5.textColor = .white
                    txt5.backgroundColor = .black
                    txt5.isEditable = false
                    view.addSubview(txt5)
                    
                    let don = UIImage(named: "donnaauguste.png")
                    let donView = UIImageView(image: don)
                    donView.frame = CGRect(x: 300, y: 310, width: 50, height: 50)
                    view.addSubview(donView)
                    let txt6 = UITextView()
                    txt6.frame = CGRect(x: 360, y: 310, width: 200, height: 40)
                    txt6.typeOn(string: "DONNA AUGUSTE.\nTHE DEVELOPER.")
                    txt6.textColor = .white
                    txt6.backgroundColor = .black
                    txt6.isEditable = false
                    view.addSubview(txt6)
                    
                    let aya = UIImage(named: "ayannahoward.png")
                    let ayaView = UIImageView(image: aya)
                    ayaView.frame = CGRect(x: 0, y: 370, width: 50, height: 50)
                    view.addSubview(ayaView)
                    let txt7 = UITextView()
                    txt7.frame = CGRect(x: 60, y: 370, width: 200, height: 40)
                    txt7.typeOn(string: "AYANNA HOWARD.\nTHE ENGINEER.")
                    txt7.textColor = .white
                    txt7.backgroundColor = .black
                    txt7.isEditable = false
                    view.addSubview(txt7)
                    
                    let ali = UIImage(named: "aliceball.png")
                    let aliView = UIImageView(image: ali)
                    aliView.frame = CGRect(x: 300, y: 370, width: 50, height: 50)
                    view.addSubview(aliView)
                    let txt8 = UITextView()
                    txt8.frame = CGRect(x: 360, y: 370, width: 200, height: 40)
                    txt8.typeOn(string: "ALICE BALL.\nTHE SCIENTIST.")
                    txt8.textColor = .white
                    txt8.backgroundColor = .black
                    txt8.isEditable = false
                    view.addSubview(txt8)
                    
                    let dor = UIImage(named: "dorothyvaughan.png")
                    let dorView = UIImageView(image: dor)
                    dorView.frame = CGRect(x: 0, y: 430, width: 50, height: 50)
                    view.addSubview(dorView)
                    let txt9 = UITextView()
                    txt9.frame = CGRect(x: 60, y: 430, width: 200, height: 40)
                    txt9.typeOn(string: "DOROTHY VAUGHAN.\nTHE INVENTOR.")
                    txt9.textColor = .white
                    txt9.backgroundColor = .black
                    txt9.isEditable = false
                    view.addSubview(txt9)
                    
                    let shi = UIImage(named: "shirleychisholm.png")
                    let shiView = UIImageView(image: shi)
                    shiView.frame = CGRect(x: 300, y: 430, width: 50, height: 50)
                    view.addSubview(shiView)
                    let txt0 = UITextView()
                    txt0.frame = CGRect(x: 360, y: 430, width: 200, height: 40)
                    txt0.typeOn(string: "SHIRLEY CHISHOLM.\nTHE ACTIVIST.")
                    txt0.textColor = .white
                    txt0.backgroundColor = .black
                    txt0.isEditable = false
                    view.addSubview(txt0)
                    
                })
            })
        }
//        view.addSubview(bgmViewG)
//        view.addSubview(bgmViewP)

        self.view = view
    }
}

extension String {
    var characterArray: [Character]{
        var characterArray = [Character]()
        for character in self {
            characterArray.append(character)
        }
        return characterArray
    }
}

extension UITextView {
    func typeOn(string: String) {
        let characterArray = string.characterArray
        var characterIndex = 0
        Timer.scheduledTimer(withTimeInterval: 0.1, repeats: true) { (timer) in
            self.text.append(characterArray[characterIndex])
            characterIndex += 1
            if characterIndex == characterArray.count {
                timer.invalidate()
            }
        }
    }
}
// Present the view controller in the Live View window
PlaygroundPage.current.liveView = MyViewController()
